/**
 * Data Processor Module
 * Processes raw metric data from WebSocket using a Web Worker
 * Separated from WebSocket and UI logic
 */
export class DataProcessor {
    constructor() {
        this.worker = new Worker('/static/js/data-worker.js');
        this.messageId = 0;
        this.pendingRequests = new Map();

        this.worker.onmessage = (e) => {
            const { id, result, error } = e.data;
            const promiseCallbacks = this.pendingRequests.get(id);
            if (promiseCallbacks) {
                this.pendingRequests.delete(id);
                if (error) {
                    promiseCallbacks.reject(new Error(error));
                } else {
                    promiseCallbacks.resolve(result);
                }
            }
        };
    }

    /**
     * Process data for a specific topic
     */
    process(topic, rawData) {
        return new Promise((resolve, reject) => {
            const id = ++this.messageId;
            this.pendingRequests.set(id, { resolve, reject });
            this.worker.postMessage({ id, topic, rawData });
        });
    }

    /**
     * Format bytes to human readable
     */
    formatBytes(bytes) {
        if (!bytes || bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    }

    /**
     * Format uptime from seconds to human readable
     */
    formatUptime(seconds) {
        if (!seconds) return 'N/A';
        const days = Math.floor(seconds / 86400);
        const hours = Math.floor((seconds % 86400) / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        return `${days}d ${hours}h ${minutes}m`;
    }
}


