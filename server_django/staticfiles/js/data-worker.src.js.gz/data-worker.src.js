/**
 * Data Worker Module
 * Offloads data parsing logic to keep the Main Thread free for rendering.
 */

const processors = new Map();

// Register default data processors
processors.set('systemstatus', (data) => {
    return data;
});

processors.set('system', (data) => {
    return {
        device_info: data.device_info || {},
        system_info: data.system_info || {},
        load_avg: data.load_avg || {}
    };
});

processors.set('cpu', (data) => {
    return {
        device_info: data.device_info || {},
        cpu_percent: data.cpu_percent || []
    };
});

processors.set('memory', (data) => {
    return {
        device_info: data.device_info || {},
        memory: data.memory || {},
        swap: data.swap || {}
    };
});

processors.set('network', (data) => {
    return {
        device_info: data.device_info || {},
        network: data.network || []
    };
});

processors.set('disk', (data) => {
    return {
        device_info: data.device_info || {},
        disk_usage: data.disk_usage || []
    };
});

processors.set('diskio', (data) => {
    return {
        device_info: data.device_info || {},
        disk_io: data.disk_io || {}
    };
});

self.onmessage = function(e) {
    const { id, topic, rawData } = e.data;
    try {
        const processor = processors.get(topic);
        let result = rawData;
        if (processor) {
            result = processor(rawData);
        }
        self.postMessage({ id, result });
    } catch (error) {
        self.postMessage({ id, error: error.message });
    }
};
